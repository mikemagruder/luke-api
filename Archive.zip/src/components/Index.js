import React from 'react';

const Index = () => {
    return (
        <div>
            <h1>Check out the new Star Wars app!!!</h1>
            <img src="https://static0.cbrimages.com/wordpress/wp-content/uploads/2020/03/yoda.jpg" alt="star wars"/>
        </div>
    )
}

export default Index;